// ********************************************************************
// ********************************************************************
function fn_parametro(par_nombreparametro) {
  var lvar_listadeparametros,
      lvar_arreglodeparametros,
      lvar_contador,
      lvar_unparametro;
  
  lvar_listadeparametros = window.location.href;
  if (!lvar_listadeparametros.includes('?') && !lvar_listadeparametros.includes('#')) {
    return '';
  }
  
  if (lvar_listadeparametros.includes('?')) {
    lvar_listadeparametros = cdr(lvar_listadeparametros, '?');
    lvar_listadeparametros = remplazarcadena(lvar_listadeparametros, '#', '&')
  } else {
    lvar_listadeparametros = cdr(lvar_listadeparametros, '#');
  }
  if (!lvar_listadeparametros) {
    return '';
  }
  
  lvar_arreglodeparametros = lvar_listadeparametros.split('&');
  for (lvar_contador in lvar_arreglodeparametros) {
    lvar_unparametro = lvar_arreglodeparametros[lvar_contador];
    if (car(lvar_unparametro, '=') === par_nombreparametro) {
      return sinescape(cdr(lvar_unparametro, '='));
    }
  }
  
  return '';
}

// ********************************************************************
function fn_validartrim(par_elobjeto) {
  if (!par_elobjeto || !par_elobjeto.value) {
    return;
  }
  
  let bvar_valor = par_elobjeto.value || '';
  par_elobjeto.value = bvar_valor.trim();
}

// ********************************************************************
// ********************************************************************



// ********************************************************************
// ********************************************************************
function fnaux_opcionesdecategoria_init() {
  let bvar_arregloopciones1 = [];
  let bvar_arregloopciones2 = ['<'+'option value="" selected>Tipo de ayuda<'+'/option>'];
  for (let bvar_contador in fn_redcs.categoriasdefinidas) {
    let bvar_unacat = fn_redcs.categoriasdefinidas[bvar_contador];
    bvar_arregloopciones1.push(bvar_unacat.nombre);
    bvar_arregloopciones2.push('<'+'option>' + bvar_unacat.nombre + '<'+'/option>');
  }
  document.getElementById('categoria').innerHTML = bvar_arregloopciones2.join('');
}


// ********************************************************************
function fnlocal_categorias() {
  fn_redcs().usuariocategorias((par_valor) => {
    if (par_valor) {
      let bvar_arregloraiz = par_valor.split('_#_');
      let bvar_arregloopciones1 = [];
      for (let bvar_contador in bvar_arregloraiz) {
        let bvar_unalinea = bvar_arregloraiz[bvar_contador].split('_|_');
        let bvar_unacat = sinescape(bvar_unalinea[0]);
        if (!bvar_arregloopciones1.includes(bvar_unacat)) {
          let bvar_nueva = {
            nombre: bvar_unacat,
            opciones: bvar_unalinea[2] ? [sinescape(bvar_unalinea[2])] : []
          };
          fn_redcs.categoriasdefinidas.push(bvar_nueva);
          fn_redcs.categoriasxnombre['c_' + bvar_unacat] = bvar_nueva;
          
          bvar_arregloopciones1.push(bvar_unacat);
        } else {
          let bvar_nueva = fn_redcs.categoriasxnombre['c_' + bvar_unacat];
          bvar_nueva.opciones.push(sinescape(bvar_unalinea[2]));
        }
      }
      
      fnaux_opcionesdecategoria_init();
    }
  });
}

// ********************************************************************
function fnlocal_en_completo() {
  let bvar_completo = document.getElementById('completo').value;
  
  if (bvar_completo === 'NO') {
    document.getElementById('motivo').parentNode.style.display = '';
  } else {
    document.getElementById('motivo').parentNode.style.display = 'none';
    
  }
}

// ********************************************************************
function fnlocal_en_borrar() {
  let bvar_confirmacion = document.getElementById('confirmaciondeborrar').value;
  
  if (bvar_confirmacion === 'SI') {
    document.getElementById('motivodeborrar').parentNode.style.display = '';
    document.getElementById('aceptardeborrar').disabled = false;
  } else {
    document.getElementById('motivodeborrar').parentNode.style.display = 'none';
    document.getElementById('aceptardeborrar').disabled = true;
    
  }
}

// ********************************************************************
function fnlocal_en_confirmar() {
  let bvar_confirmacion = document.getElementById('satisfaccion').value;
  
  document.getElementById('botondeconfirmar').disabled = !bvar_confirmacion;
}

// ********************************************************************
function fnlocal_en_categoria() {
  let bvar_categoria = document.getElementById('categoria').value;
  let bvar_arregloopciones2 = ['<'+'option value="" selected>Detalle de la ayuda<'+'/option>'];
  
  if (fn_redcs.categoriasxnombre['c_' + bvar_categoria]) {
    let bvar_nueva = fn_redcs.categoriasxnombre['c_' + bvar_categoria].opciones;
    for (let bvar_contador in bvar_nueva) {
      let bvar_unacat = bvar_nueva[bvar_contador];
      bvar_arregloopciones2.push('<'+'option>' + bvar_unacat + '<'+'/option>');
    }
  } else {
    bvar_arregloopciones2.splice(0, 0, '<'+'optgroup label="Primero debe seleccionar el tipo de ayuda"><'+'/optgroup>');
  }
  
  document.getElementById('subcategoria').innerHTML = bvar_arregloopciones2.join('');
}

// ********************************************************************
function fnlocal_en_politica() {
  document.getElementById('botonenviar').disabled = !document.getElementById('politicaprivacidad').checked;
}

// ********************************************************************
function fnlocal_en_zona(par_callback) {
  let bvar_zona = document.getElementById('ubicacionrural').value;
  
  if (bvar_zona) {
    objetohtml_estadodisplay('datosquedependendezona');
    if (bvar_zona === 'Rural') {
      document.getElementById('vereda').parentNode.style.display = '';
      document.getElementById('interior').parentNode.style.display = 'none';
      
      fn_cargando().mostrar('Espera un momento ...')
      fn_redcs().usuarioveredas((par_valor) => {
        fn_cargando().ocultar();
        if (par_valor) {
          let bvar_arregloraiz = par_valor.split('_#_');
          let bvar_arregloopciones1 = ['<'+'option value="" selected>Seleccionar vereda<'+'/option>'];
          for (let bvar_contador in bvar_arregloraiz) {
            let bvar_unalinea = bvar_arregloraiz[bvar_contador].split('_|_');
            let bvar_unacat = sinescape(bvar_unalinea[0]);
            if (bvar_unacat) {
              bvar_arregloopciones1.push('<'+'option value="' + bvar_unalinea[1] + '">' + bvar_unacat + '<'+'/option>');
            }
          }
          
          document.getElementById('vereda').innerHTML = bvar_arregloopciones1.join('');
        }
        if (par_callback) {
          par_callback();
        }
      });
      
    } else {
      document.getElementById('vereda').parentNode.style.display = 'none';
      document.getElementById('interior').parentNode.style.display = '';
      if (par_callback) {
        par_callback();
      }
    }
  } else {
    objetohtml_estadonodisplay('datosquedependendezona');
    if (par_callback) {
      par_callback();
    }
  }
}
// ********************************************************************
// ********************************************************************


// ********************************************************************
// ********************************************************************
function fnlocal_politica() {
  fn_redcs().usuariopoliticas((par_valor) => {
    if (par_valor) {
      document.getElementById('textodepolitica').innerHTML = par_valor;
    }
  });
}
// ********************************************************************
// ********************************************************************



// ********************************************************************
// ********************************************************************
function fnaux_cerrar_solicitud(par_solicitud_objeto_id, par_ofrecimiento_objeto_id) {
  document.getElementById('cerrar_solicitud').value = par_solicitud_objeto_id;
  document.getElementById('cerrar_ofrecimiento').value = par_ofrecimiento_objeto_id;
  
  document.getElementById('completo').value = '';
  fnlocal_en_completo();
  
  document.getElementById('motivo').value = '';
  document.getElementById('aseguir').value = 'SI';
}
// ********************************************************************
// ********************************************************************



// ********************************************************************
// ********************************************************************
function fnaux_confirmarquemeayudaron(par_objeto_id) {
  document.getElementById('satisfaccion').value = '';
  fnlocal_en_confirmar();
  document.getElementById('comentarioayudarecibida').value = '';
  document.getElementById('confirmarmeayudaron').value = par_objeto_id;
}

// ********************************************************************
function fnaux_en_yoayudo(par_ofrecimiento, par_solicitud) {
  let bvar_contenido = document.getElementById('plantilla_textodedetalle_yoayudo').innerHTML;
  let bvar_ofrecimiento = fn_sos.ofrecimientos['o_' + par_ofrecimiento];
  let bvar_solicitud = fn_sos.solicitudes['s_' + par_solicitud] || fn_sos.otrassolicitudes['s_' + par_solicitud] ;
  
  bvar_contenido = bvar_contenido.replace(/_#nombre#_/gim, bvar_solicitud.nombre);
  bvar_contenido = bvar_contenido.replace(/_#celular#_/gim, bvar_solicitud.celular);
  bvar_contenido = bvar_contenido.replace(/_#detalle#_/gim, bvar_solicitud.detalle.replace(/\n/gm, '<br>'));
  bvar_contenido = bvar_contenido.replace(/_#categoria#_/gim, bvar_ofrecimiento.categoria);
  bvar_contenido = bvar_contenido.replace(/_#subcategoria#_/gim, bvar_solicitud.subcategoria);
  
  bvar_contenido = bvar_contenido.replace(/_#ofrecimiento#_/gim, par_ofrecimiento);
  bvar_contenido = bvar_contenido.replace(/_#solicitud#_/gim, par_solicitud);
  
  document.getElementById('textodedetalle_yoayudo').innerHTML = bvar_contenido;
}

// ********************************************************************
function fnaux_mostrarcoincidencias(par_objeto_id) {
  if (document.getElementById('coincidencias_' + par_objeto_id).style.display === 'none') {
    objetohtml_estadodisplay('coincidencias_' + par_objeto_id);
  } else {
    objetohtml_estadonodisplay('coincidencias_' + par_objeto_id);
  }
}

// ********************************************************************
function fnaux_nomostrarcoincidencias(par_objeto_id) {
  objetohtml_estadonodisplay('coincidencias_' + par_objeto_id);
}

// ********************************************************************
function fnaux_mostrarotrascoincidencias(par_objeto_id) {
  if (document.getElementById('otrascoincidencias_' + par_objeto_id).style.display === 'none') {
    objetohtml_estadodisplay('otrascoincidencias_' + par_objeto_id);
  } else {
    objetohtml_estadonodisplay('otrascoincidencias_' + par_objeto_id);
  }
}

// ********************************************************************
function fnaux_nomostrarotrascoincidencias(par_objeto_id) {
  objetohtml_estadonodisplay('otrascoincidencias_' + par_objeto_id);
}

// ********************************************************************
function fnaux_listaenproceso(par_respuesta) {
  if (!par_respuesta.enproceso) {
    objetohtml_estadonodisplay('lista_enproceso');
    return;
  }
  
  objetohtml_estadodisplay('lista_enproceso');
  
  let bvar_arreglo = par_respuesta.enproceso.split('_#_');
  let bvar_opciones = [];
  let bvar_estiloresponsive = false;
  if (getComputedStyle(document.getElementById('testigo_responsive')).display === 'none') {
    // Responsive
    bvar_estiloresponsive = true;
  }
  
  for (let bvar_contador in bvar_arreglo) {
    let bvar_unalinea = bvar_arreglo[bvar_contador].split('_|_').map(entrada => sinescape(entrada));
    let bvar_estado_id = bvar_unalinea[1];
    let bvar_contenido;
    let bvar_plantillabotoncerrar;
    if (!bvar_estiloresponsive) {
      bvar_contenido = document.getElementById('plantilla_listaenproceso_noresponsive').innerHTML;
    } else {
      bvar_contenido = document.getElementById('plantilla_listaenproceso_responsive').innerHTML;
    }
    bvar_plantillabotoncerrar = document.getElementById('plantilla_boton_cerrar').innerHTML;
    bvar_plantillabotoncerrar = bvar_plantillabotoncerrar.replace(/_#solicitud_objeto_id#_/gim, bvar_unalinea[0]);
    bvar_plantillabotoncerrar = bvar_plantillabotoncerrar.replace(/_#ofrecimiento_objeto_id#_/gim, bvar_unalinea[2]);
    
    bvar_contenido = bvar_contenido.replace(/_#contador#_/gim, (valorentero(bvar_contador)+1)+'');
    
    let bvar_unestado = fn_sos.estados['e_' + bvar_estado_id];
    if (bvar_unestado) {
      bvar_contenido = bvar_contenido.replace(/_#estado#_/gim, bvar_unestado.estado_tituloparalistado);
      bvar_contenido = bvar_contenido.replace(/_#colorfondo#_/gim, bvar_unestado.estado_colorfondo);
      bvar_contenido = bvar_contenido.replace(/_#colorfuente#_/gim, bvar_unestado.estado_colorfuente);
      
    } else {
      bvar_contenido = bvar_contenido.replace(/_#estado#_/gim, bvar_unalinea[1]);
      bvar_contenido = bvar_contenido.replace(/_#colorfondo#_/gim, 'unset');
      bvar_contenido = bvar_contenido.replace(/_#colorfuente#_/gim, 'unset');
    }
    
    bvar_contenido = bvar_contenido.replace(/_#acciones#_/gim, bvar_plantillabotoncerrar);
    
    bvar_contenido = bvar_contenido.replace(/_#categoria#_/gim, bvar_unalinea[8]);
    bvar_contenido = bvar_contenido.replace(/_#subcategoria#_/gim, bvar_unalinea[9]);
    bvar_contenido = bvar_contenido.replace(/_#detalle#_/gim, (bvar_unalinea[10]).replace(/\n/gm, '<br>'));
    
    bvar_contenido = bvar_contenido.replace(/_#solicitante_nombre#_/gim, bvar_unalinea[12]);
    bvar_contenido = bvar_contenido.replace(/_#solicitante_celular#_/gim, bvar_unalinea[13]);
    
    bvar_opciones.push(bvar_contenido);
  }
  bvar_opciones.sort();
  
  if (bvar_estiloresponsive) {
    document.getElementById('lista_body_enproceso_responsive').innerHTML = bvar_opciones.join('');
    objetohtml_estadonodisplay('lista_tabla_enproceso_noresponsive');
  } else {
    document.getElementById('lista_body_enproceso_noresponsive').innerHTML = bvar_opciones.join('');
  }
}

// ***************************************
function fnaux_listaconsolicitudes(par_respuesta) {
  if (!par_respuesta.consolicitudes) {
    objetohtml_estadonodisplay('lista_consolicitudes');
    objetohtml_estadonodisplay('lista_otrassolicitudes');
    return;
  }
  
  debugger;
  objetohtml_estadodisplay('lista_consolicitudes');
  objetohtml_estadodisplay('lista_otrassolicitudes');
  
  let bvar_arreglo = par_respuesta.consolicitudes.split('_#_');
  let bvar_opciones = [];
  let bvar_estiloresponsive = false;
  if (getComputedStyle(document.getElementById('testigo_responsive')).display === 'none') {
    // Responsive
    bvar_estiloresponsive = true;
  }
  
  fn_sos.ofrecimientos = [];
  fn_sos.solicitudes = [];
  fn_sos.otrassolicitudes = [];
  let bvar_categorias = [];
  for (let bvar_contador in bvar_arreglo) {
    let bvar_unalinea = bvar_arreglo[bvar_contador].split('_|_').map(entrada => sinescape(entrada));
    if (!bvar_categorias['c_' + bvar_unalinea[7] + '|' + bvar_unalinea[5]]) {
      let bvar_nueva = {
        objeto_id: bvar_unalinea[0],
        categoria: bvar_unalinea[7],
        subcategoria: bvar_unalinea[5],
        detalle: bvar_unalinea[6],
        estado: bvar_unalinea[1],
        
        solicitudes: []
      };
      bvar_categorias['c_' + bvar_unalinea[7] + '|' + bvar_unalinea[5]] = bvar_nueva;
      fn_sos.ofrecimientos['o_' + bvar_nueva.objeto_id] = bvar_nueva;
    }
    
    let bvar_nuevasol = {
      objeto_id: bvar_unalinea[15],
      nombre: bvar_unalinea[9],
      celular: bvar_unalinea[10],
      fecha: car(bvar_unalinea[11], ' '),
      hora: tar(bvar_unalinea[12], ' '),
      subcategoria: bvar_unalinea[13],
      detalle: bvar_unalinea[14]
    };
    bvar_categorias['c_' + bvar_unalinea[7] + '|' + bvar_unalinea[5]].solicitudes.push(bvar_nuevasol);
    if (bvar_unalinea[5] === bvar_unalinea[13]) {
      if (!fn_sos.solicitudes['s_' + bvar_nuevasol.objeto_id]) {
        fn_sos.solicitudes['s_' + bvar_nuevasol.objeto_id] = bvar_nuevasol;
      }
    } else {
      if (!fn_sos.otrassolicitudes['s_' + bvar_nuevasol.objeto_id]) {
        fn_sos.otrassolicitudes['s_' + bvar_nuevasol.objeto_id] = bvar_nuevasol;
      }
    }
  }
  
  let bvar_solicitudesyaincluidas = [];
  // Coincidencias de 2 criterios
  let bvar_cantidad = 0;
  for (let bvar_contador in bvar_categorias) {
    bvar_cantidad++;
    let bvar_unofrecimiento = bvar_categorias[bvar_contador];
  
    let bvar_estado_id = bvar_unofrecimiento.estado;
    let bvar_contenido;
    let bvar_plantillabotoncantidad;
    if (!bvar_estiloresponsive) {
      bvar_contenido = document.getElementById('plantilla_listadeofrecimientosconsolicitudes_noresponsive').innerHTML;
    } else {
      bvar_contenido = document.getElementById('plantilla_listadeofrecimientosconsolicitudes_responsive').innerHTML;
    }
  
    bvar_contenido = bvar_contenido.replace(/_#contador#_/gim, bvar_cantidad + '');
  
    let bvar_unestado = fn_sos.estados['e_' + bvar_estado_id];
    if (bvar_unestado) {
      bvar_contenido = bvar_contenido.replace(/_#estado#_/gim, bvar_unestado.estado_tituloparalistado);
      bvar_contenido = bvar_contenido.replace(/_#colorfondo#_/gim, bvar_unestado.estado_colorfondo);
      bvar_contenido = bvar_contenido.replace(/_#colorfuente#_/gim, bvar_unestado.estado_colorfuente);
    
    } else {
      bvar_contenido = bvar_contenido.replace(/_#estado#_/gim, bvar_unofrecimiento.estado);
      bvar_contenido = bvar_contenido.replace(/_#colorfondo#_/gim, 'unset');
      bvar_contenido = bvar_contenido.replace(/_#colorfuente#_/gim, 'unset');
    }
  
    bvar_contenido = bvar_contenido.replace(/_#objeto_id#_/gim, bvar_unofrecimiento.objeto_id);
    bvar_contenido = bvar_contenido.replace(/_#categoria#_/gim, bvar_unofrecimiento.categoria);
    bvar_contenido = bvar_contenido.replace(/_#subcategoria#_/gim, bvar_unofrecimiento.subcategoria);
    bvar_contenido = bvar_contenido.replace(/_#detalle#_/gim, (bvar_unofrecimiento.detalle).replace(/\n/gm, '<br>'));
  
    let bvar_solicitudes = [];
    for (let bvar_contador2 in bvar_unofrecimiento.solicitudes) {
      let bvar_unasolicitud = bvar_unofrecimiento.solicitudes[bvar_contador2];
      if (bvar_unofrecimiento.subcategoria === bvar_unasolicitud.subcategoria) {
        let bvar_contenidofila;
        if (bvar_estiloresponsive) {
          bvar_contenidofila = document.getElementById('plantilla_listadeofrecimientosconsolicitudes_responsive_detalles_2criterios_fila').innerHTML;
        } else {
          bvar_contenidofila = document.getElementById('plantilla_listadeofrecimientosconsolicitudes_noresponsive_detalles_2criterios_fila').innerHTML;
        }
        bvar_contenidofila = bvar_contenidofila.replace(/_#nombre#_/gim, bvar_unasolicitud.nombre);
        bvar_contenidofila = bvar_contenidofila.replace(/_#celular#_/gim, bvar_unasolicitud.celular);
        bvar_contenidofila = bvar_contenidofila.replace(/_#detalle#_/gim, (bvar_unasolicitud.detalle).replace(/\n/gm, '<br>'));
  
        let bvar_botonyoayudo = document.getElementById('plantilla_listadeofrecimientosconsolicitudes_botonyoayudo').innerHTML;
        bvar_botonyoayudo = bvar_botonyoayudo.replace(/_#ofrecimiento_objeto_id#_/gim, bvar_unofrecimiento.objeto_id);
        bvar_botonyoayudo = bvar_botonyoayudo.replace(/_#solicitud_objeto_id#_/gim, bvar_unasolicitud.objeto_id);
  
        bvar_contenidofila = bvar_contenidofila.replace(/_#acciones#_/gim, bvar_botonyoayudo);
        bvar_solicitudes.push(bvar_contenidofila);
        bvar_solicitudesyaincluidas.push(bvar_unasolicitud.objeto_id);
      }
    }
    if (bvar_solicitudes.length > 0) {
      let bvar_contenidosolicitudes;
      if (bvar_estiloresponsive) {
        bvar_contenidosolicitudes = document.getElementById('plantilla_listadeofrecimientosconsolicitudes_responsive_detalles_2criterios').innerHTML;
      } else {
        bvar_contenidosolicitudes = document.getElementById('plantilla_listadeofrecimientosconsolicitudes_noresponsive_detalles_2criterios').innerHTML;
      }
      bvar_contenidosolicitudes = bvar_contenidosolicitudes.replace(/<!--_#filas#_-->/gim, bvar_solicitudes.join(''));
  
      if (bvar_solicitudes.length === 1) {
        bvar_plantillabotoncantidad = document.getElementById('plantilla_listadeofrecimientosconsolicitudes_botoncoincidencias_1').innerHTML;
      } else {
        bvar_plantillabotoncantidad = document.getElementById('plantilla_listadeofrecimientosconsolicitudes_botoncoincidencias_n').innerHTML;
        bvar_plantillabotoncantidad = bvar_plantillabotoncantidad.replace(/_#cantidad#_/gim, bvar_solicitudes.length.toString(10));
      }
      bvar_plantillabotoncantidad = bvar_plantillabotoncantidad.replace(/_#objeto_id#_/gim, bvar_unofrecimiento.objeto_id);
      bvar_contenido = bvar_contenido.replace(/_#acciones#_/gim, bvar_plantillabotoncantidad);
      
      bvar_contenido = bvar_contenido.replace(/_#solicitudes#_/gim, bvar_contenidosolicitudes);
      
      bvar_opciones.push(bvar_contenido);
    }
  }
  
  if (bvar_estiloresponsive) {
    document.getElementById('lista_body_consolicitudes_responsive').innerHTML = bvar_opciones.join('');
    objetohtml_estadonodisplay('lista_tabla_consolicitudes_noresponsive');
  } else {
    document.getElementById('lista_body_consolicitudes_noresponsive').innerHTML = bvar_opciones.join('');
  }
  
  
  // ---------------------------
  // Coincidencias de 1 criterio
  bvar_opciones = [];
  bvar_cantidad = 0;
  for (let bvar_contador in bvar_categorias) {
    bvar_cantidad++;
    let bvar_unofrecimiento = bvar_categorias[bvar_contador];
  
    let bvar_estado_id = bvar_unofrecimiento.estado;
    let bvar_contenido;
    let bvar_plantillabotoncantidad;
    if (!bvar_estiloresponsive) {
      bvar_contenido = document.getElementById('plantilla_listadeofrecimientosotrassolicitudes_noresponsive').innerHTML;
    } else {
      bvar_contenido = document.getElementById('plantilla_listadeofrecimientosotrassolicitudes_responsive').innerHTML;
    }
  
    bvar_contenido = bvar_contenido.replace(/_#contador#_/gim, bvar_cantidad + '');
  
    let bvar_unestado = fn_sos.estados['e_' + bvar_estado_id];
    if (bvar_unestado) {
      bvar_contenido = bvar_contenido.replace(/_#estado#_/gim, bvar_unestado.estado_tituloparalistado);
      bvar_contenido = bvar_contenido.replace(/_#colorfondo#_/gim, bvar_unestado.estado_colorfondo);
      bvar_contenido = bvar_contenido.replace(/_#colorfuente#_/gim, bvar_unestado.estado_colorfuente);
    
    } else {
      bvar_contenido = bvar_contenido.replace(/_#estado#_/gim, bvar_unofrecimiento.estado);
      bvar_contenido = bvar_contenido.replace(/_#colorfondo#_/gim, 'unset');
      bvar_contenido = bvar_contenido.replace(/_#colorfuente#_/gim, 'unset');
    }
  
    bvar_contenido = bvar_contenido.replace(/_#objeto_id#_/gim, bvar_unofrecimiento.objeto_id);
    bvar_contenido = bvar_contenido.replace(/_#categoria#_/gim, bvar_unofrecimiento.categoria);
    bvar_contenido = bvar_contenido.replace(/_#subcategoria#_/gim, bvar_unofrecimiento.subcategoria);
    bvar_contenido = bvar_contenido.replace(/_#detalle#_/gim, (bvar_unofrecimiento.detalle).replace(/\n/gm, '<br>'));
  
    let bvar_solicitudes = [];
    for (let bvar_contador2 in bvar_unofrecimiento.solicitudes) {
      let bvar_unasolicitud = bvar_unofrecimiento.solicitudes[bvar_contador2];
      if ((bvar_unofrecimiento.subcategoria !== bvar_unasolicitud.subcategoria)
          && !bvar_solicitudesyaincluidas.includes(bvar_unasolicitud.objeto_id)) {
        let bvar_contenidofila;
        if (bvar_estiloresponsive) {
          bvar_contenidofila = document.getElementById('plantilla_listadeofrecimientosotrassolicitudes_responsive_detalles_1criterio_fila').innerHTML;
        } else {
          bvar_contenidofila = document.getElementById('plantilla_listadeofrecimientosotrassolicitudes_noresponsive_detalles_1criterio_fila').innerHTML;
        }
        bvar_contenidofila = bvar_contenidofila.replace(/_#nombre#_/gim, bvar_unasolicitud.nombre);
        bvar_contenidofila = bvar_contenidofila.replace(/_#celular#_/gim, bvar_unasolicitud.celular);
        bvar_contenidofila = bvar_contenidofila.replace(/_#detalle#_/gim, (bvar_unasolicitud.detalle).replace(/\n/gm, '<br>'));
        bvar_contenidofila = bvar_contenidofila.replace(/_#subcategoria#_/gim, bvar_unasolicitud.subcategoria);
  
        let bvar_botonyoayudo = document.getElementById('plantilla_listadeofrecimientosotrassolicitudes_botonyoayudo').innerHTML;
        bvar_botonyoayudo = bvar_botonyoayudo.replace(/_#ofrecimiento_objeto_id#_/gim, bvar_unofrecimiento.objeto_id);
        bvar_botonyoayudo = bvar_botonyoayudo.replace(/_#solicitud_objeto_id#_/gim, bvar_unasolicitud.objeto_id);
  
        bvar_contenidofila = bvar_contenidofila.replace(/_#acciones#_/gim, bvar_botonyoayudo);
        bvar_solicitudes.push(bvar_contenidofila);
        bvar_solicitudesyaincluidas.push(bvar_unasolicitud.objeto_id);
      }
    }
    if (bvar_solicitudes.length > 0) {
      let bvar_contenidosolicitudes;
      if (bvar_estiloresponsive) {
        bvar_contenidosolicitudes = document.getElementById('plantilla_listadeofrecimientosotrassolicitudes_responsive_detalles_2criterios').innerHTML;
      } else {
        bvar_contenidosolicitudes = document.getElementById('plantilla_listadeofrecimientosotrassolicitudes_noresponsive_detalles_2criterios').innerHTML;
      }
      bvar_contenidosolicitudes = bvar_contenidosolicitudes.replace(/<!--_#filas#_-->/gim, bvar_solicitudes.join(''));
  
      if (bvar_solicitudes.length === 1) {
        bvar_plantillabotoncantidad = document.getElementById('plantilla_listadeofrecimientosotrassolicitudes_botoncoincidencias_1').innerHTML;
      } else {
        bvar_plantillabotoncantidad = document.getElementById('plantilla_listadeofrecimientosotrassolicitudes_botoncoincidencias_n').innerHTML;
        bvar_plantillabotoncantidad = bvar_plantillabotoncantidad.replace(/_#cantidad#_/gim, bvar_solicitudes.length.toString(10));
      }
      bvar_plantillabotoncantidad = bvar_plantillabotoncantidad.replace(/_#objeto_id#_/gim, bvar_unofrecimiento.objeto_id);
      bvar_contenido = bvar_contenido.replace(/_#acciones#_/gim, bvar_plantillabotoncantidad);
      
      bvar_contenido = bvar_contenido.replace(/_#solicitudes#_/gim, bvar_contenidosolicitudes);
      
      bvar_opciones.push(bvar_contenido);
    }
  }
  
  if (bvar_opciones.length) {
    if (bvar_estiloresponsive) {
      document.getElementById('lista_body_otrassolicitudes_responsive').innerHTML = bvar_opciones.join('');
      objetohtml_estadonodisplay('lista_tabla_otrassolicitudes_noresponsive');
    } else {
      document.getElementById('lista_body_otrassolicitudes_noresponsive').innerHTML = bvar_opciones.join('');
    }
  } else {
    objetohtml_estadonodisplay('lista_otrassolicitudes');
  }
  
}

// ***************************************
function fnaux_listadetodos(par_respuesta) {
  if (!par_respuesta.todos) {
    objetohtml_estadonodisplay('lista_tabla_noresponsive');
    objetohtml_estadonodisplay('lista_titulo_noresponsive');
    objetohtml_estadodisplay('lista_body_responsive');
    
    document.getElementById('lista_body_responsive').innerHTML = '<strong>No se encontraron ofrecimientos publicados.</strong>';
    
    return;
  }
  
  let bvar_arreglo = par_respuesta.todos.split('_#_');
  let bvar_opciones = [];
  let bvar_estiloresponsive = false;
  if (getComputedStyle(document.getElementById('testigo_responsive')).display === 'none') {
    // Responsive
    bvar_estiloresponsive = true;
  }
  
  for (let bvar_contador in bvar_arreglo) {
    let bvar_unalinea = bvar_arreglo[bvar_contador].split('_|_').map(entrada => sinescape(entrada));
    let bvar_estado_id = bvar_unalinea[1];
    let bvar_contenido;
    let bvar_botoneliminar;
    let bvar_botonsuspender;
    let bvar_botonagotar;
    let bvar_botonactivar;
    if (!bvar_estiloresponsive) {
      bvar_contenido = document.getElementById('plantilla_listatodos_noresponsive').innerHTML;
    } else {
      bvar_contenido = document.getElementById('plantilla_listatodos_responsive').innerHTML;
    }
    
    bvar_botoneliminar = document.getElementById('plantilla_boton_eliminar').innerHTML;
    bvar_botonsuspender = document.getElementById('plantilla_boton_suspender').innerHTML;
    bvar_botonagotar = document.getElementById('plantilla_boton_agotar').innerHTML;
    bvar_botonactivar = document.getElementById('plantilla_boton_activar').innerHTML;
    
    bvar_contenido = bvar_contenido.replace(/_#contador#_/gim, (valorentero(bvar_contador)+1)+'');
    
    let bvar_unestado = fn_sos.estados['e_' + bvar_estado_id];
    if (bvar_unestado) {
      bvar_contenido = bvar_contenido.replace(/_#estado#_/gim, bvar_unestado.estado_tituloparalistado);
      bvar_contenido = bvar_contenido.replace(/_#colorfondo#_/gim, bvar_unestado.estado_colorfondo);
      bvar_contenido = bvar_contenido.replace(/_#colorfuente#_/gim, bvar_unestado.estado_colorfuente);
      
    } else {
      bvar_contenido = bvar_contenido.replace(/_#estado#_/gim, bvar_unalinea[1]);
      bvar_contenido = bvar_contenido.replace(/_#colorfondo#_/gim, 'unset');
      bvar_contenido = bvar_contenido.replace(/_#colorfuente#_/gim, 'unset');
    }
    
    let bvar_botones = '';
    if (['10113', '10114', '10117'].includes(bvar_estado_id)) {
      bvar_botones += bvar_botoneliminar.replace(/_#objeto_id#_/gim, bvar_unalinea[0]);
    }
    if (['10113', '10117'].includes(bvar_estado_id)) {
      bvar_botones += bvar_botonsuspender.replace(/_#objeto_id#_/gim, bvar_unalinea[0]);
    }
    if (['10113', '10114'].includes(bvar_estado_id)) {
      bvar_botones += bvar_botonagotar.replace(/_#objeto_id#_/gim, bvar_unalinea[0]);
    }
    if (['10114', '10117'].includes(bvar_estado_id)) {
      bvar_botones += bvar_botonactivar.replace(/_#objeto_id#_/gim, bvar_unalinea[0]);
    }
    
    bvar_contenido = bvar_contenido.replace(/_#acciones#_/gim, bvar_botones);
    
    bvar_contenido = bvar_contenido.replace(/_#categoria#_/gim, bvar_unalinea[5]);
    bvar_contenido = bvar_contenido.replace(/_#subcategoria#_/gim, bvar_unalinea[6]);
    bvar_contenido = bvar_contenido.replace(/_#detalle#_/gim, (bvar_unalinea[7]).replace(/\n/gm, '<br>'));
    
    bvar_opciones.push(bvar_contenido);
  }
  bvar_opciones.sort();
  
  if (bvar_estiloresponsive) {
    document.getElementById('lista_body_responsive').innerHTML = bvar_opciones.join('');
    objetohtml_estadonodisplay('lista_tabla_noresponsive');
  } else {
    document.getElementById('lista_body_noresponsive').innerHTML = bvar_opciones.join('');
  }
}

// ***************************************
function fnaux_milista(par_tipo) {
  fn_cargando().mostrar('Espera un momento ...');
  
  if (par_tipo === 'o') {
    // Ofrecimientos
    fn_redcs().usuarioofrecimientos((par_res) => {
      let bvar_respuesta = JSON.parse(par_res);
  
      fnaux_listaenproceso(bvar_respuesta);
      fnaux_listaconsolicitudes(bvar_respuesta);
      fnaux_listadetodos(bvar_respuesta);
    
      fn_cargando().ocultar();
    });

  } else {
    // Solicitudes
    fn_redcs().usuariosolicitudes((par_res) => {
      let bvar_arreglo = par_res.split('_#_');
      let bvar_opciones = [];
      let bvar_estiloresponsive = false;
      if (getComputedStyle(document.getElementById('testigo_responsive')).display === 'none') {
        // Responsive
        bvar_estiloresponsive = true;
      }
      
      
      for (let bvar_contador in bvar_arreglo) {
        let bvar_unalinea = bvar_arreglo[bvar_contador].split('_|_');
        let bvar_estado_id = bvar_unalinea[1];
        let bvar_contenido;
        let bvar_plantillabotonconfirmar;
        if (!bvar_estiloresponsive) {
          bvar_contenido = document.getElementById('plantilla_listadesolicitudes_noresponsive').innerHTML;
        } else {
          bvar_contenido = document.getElementById('plantilla_listadesolicitudes_responsive').innerHTML;
        }
        
        bvar_contenido = bvar_contenido.replace(/_#contador#_/gim, (valorentero(bvar_contador)+1)+'');
        bvar_contenido = bvar_contenido.replace(/_#fecha#_/gim, car(sinescape(bvar_unalinea[5]), ' '));
        bvar_contenido = bvar_contenido.replace(/_#hora#_/gim, cdr(sinescape(bvar_unalinea[6]), ' '));
    
        let bvar_unestado = fn_sos.estados['e_' + bvar_estado_id];
        if (bvar_unestado) {
          bvar_contenido = bvar_contenido.replace(/_#estado#_/gim, bvar_unestado.estado_tituloparalistado);
          bvar_contenido = bvar_contenido.replace(/_#colorfondo#_/gim, bvar_unestado.estado_colorfondo);
          bvar_contenido = bvar_contenido.replace(/_#colorfuente#_/gim, bvar_unestado.estado_colorfuente);
          
        } else {
          bvar_contenido = bvar_contenido.replace(/_#estado#_/gim, sinescape(bvar_unalinea[1]));
          bvar_contenido = bvar_contenido.replace(/_#colorfondo#_/gim, 'unset');
          bvar_contenido = bvar_contenido.replace(/_#colorfuente#_/gim, 'unset');
        }
  
        if (bvar_estado_id === '10116') {
          bvar_plantillabotonconfirmar = document.getElementById('plantilla_boton_confirmar').innerHTML;
          bvar_plantillabotonconfirmar = bvar_plantillabotonconfirmar.replace(/_#solicitud_id#_/gim, bvar_unalinea[0]);
          bvar_contenido = bvar_contenido.replace(/_#acciones#_/gim, bvar_plantillabotonconfirmar);
        } else {
          bvar_contenido = bvar_contenido.replace(/_#acciones#_/gim, '');
        }
        
        bvar_contenido = bvar_contenido.replace(/_#categoria#_/gim, sinescape(bvar_unalinea[7]));
        bvar_contenido = bvar_contenido.replace(/_#subcategoria#_/gim, sinescape(bvar_unalinea[8]));
        bvar_contenido = bvar_contenido.replace(/_#detalle#_/gim, sinescape(bvar_unalinea[9]));
        
        bvar_opciones.push(bvar_contenido);
      }
      bvar_opciones.sort();
      bvar_opciones.reverse();
    
      if (bvar_estiloresponsive) {
        document.getElementById('lista_body_responsive').innerHTML = bvar_opciones.join('');
        objetohtml_estadonodisplay('lista_tabla_noresponsive');
      } else {
        document.getElementById('lista_body_noresponsive').innerHTML = bvar_opciones.join('');
        
      }
      
      fn_cargando().ocultar();
    });
  }
}


function fn_sos() {
  return {
    // Ej: fn_sos().mostrarlista(tipo); s | o
    mostrarlista: (par_tipo) => {
      objetohtml_estadonodisplay('respuesta_caja');
      objetohtml_estadonodisplay('formulario_caja');
      objetohtml_estadodisplay('lista_caja');
      
      if (!fn_sos.estados) {
        fn_redcs().usuarioestados((par_resultado) => {
          if (!par_resultado) {
            alert('Error');
            return;
          }
  
          fn_sos.estados = [];
          let bvar_estados = par_resultado.split('_#_');
          for (let bvar_contador in bvar_estados) {
            let bvar_unalinea = bvar_estados[bvar_contador].split('_|_');
            let bvar_estado_id = bvar_unalinea[0];
            // estado_id,estado_clasificacion_id,estado_colorfondo,estado_colorfuente,estado_tituloparalistado
            let bvar_unestado = {
              estado_id: bvar_estado_id,
              estado_clasificacion_id: bvar_unalinea[1],
              estado_colorfondo: sinescape(bvar_unalinea[2]),
              estado_colorfuente: sinescape(bvar_unalinea[3]),
              estado_tituloparalistado: sinescape(bvar_unalinea[4])
            };
            fn_sos.estados['e_' + bvar_estado_id] = bvar_unestado;
          }
  
          fnaux_milista(par_tipo);
        });
        
      } else {
        fnaux_milista(par_tipo);
      }
      
      
    },
    // Ej: fn_sos().mostrarformulario();
    mostrarformulario: () => {
      objetohtml_estadonodisplay('respuesta_caja');
      objetohtml_estadodisplay('formulario_caja');
      objetohtml_estadonodisplay('lista_caja');
      
      document.getElementById('categoria').value = '';
      fnlocal_en_categoria();
      document.getElementById('descripcionayuda').value = '';
  
      document.getElementById('politicaprivacidad').checked = false;
      fnlocal_en_politica();
    },
    // Ej: fn_sos().mostrarrespuesta();
    mostrarrespuesta: () => {
      objetohtml_estadodisplay('respuesta_caja');
      objetohtml_estadonodisplay('formulario_caja');
      objetohtml_estadonodisplay('lista_caja');
    },
    
    
    // ----------------------------------------------------------------------
  
    // Ej: fn_sos().actualizarusuario();
    actualizarusuario: () => {
      // Valida primero los datos.
      if (!fn_sos().validardatosdeusuario()) {
        return;
      }
      
      fn_cargando().mostrar('Espera un momento ...');
      let bvar_paquete = {
        comando: 'usuario-actualizar',
    
        nombre: document.getElementById('nombre').value,
        documento: document.getElementById('documento').value,
        tipodocumento: document.getElementById('tipodocumento').value,
        correo: document.getElementById('correo').value,
        celular: document.getElementById('celular').value,
        ubicacionrural: document.getElementById('ubicacionrural').value,
        vereda: document.getElementById('vereda').value,
        direccion: document.getElementById('direccion').value,
        interior: document.getElementById('interior').value,
        ciudad: document.getElementById('ciudad').value,
        ubicacion: document.getElementById('ubicacion').value,
        telefono: document.getElementById('telefono').value,
    
        aceptopublicarnombre: document.getElementById('aceptopublicarnombre').checked ? document.getElementById('aceptopublicarnombre').value : 'NO',
        aceptocontactocelular: document.getElementById('aceptocontactocelular').checked ? document.getElementById('aceptocontactocelular').value : 'NO',
        aceptocontactowhatsapp: document.getElementById('aceptocontactowhatsapp').checked ? document.getElementById('aceptocontactowhatsapp').value : 'NO',
        aceptocontactocorreo: document.getElementById('aceptocontactocorreo').checked ? document.getElementById('aceptocontactocorreo').value : 'NO'
      };
  
      // Hace post
      wspost_cb(
          { url: '/ws/app/usuario', datos: 'config=' + conescape(JSON.stringify(bvar_paquete)) },
          (par_error, par_resultado) => {
            fn_cargando().ocultar();
            if (par_error) {
              alert('ERROR: ' + par_error);
            } else {
              fn_redcs().visitaropcion('/redcs/');
            }
          });
    },
  
  
    // Ej: lvar_resultado = fn_sos().validardatosdeusuario();
    validardatosdeusuario: () => {
      if (!document.getElementById('nombre').value) {
        objetohtml_enfocar('nombre');
        alert('Debe ingresar un nombre');
        objetohtml_enfocar('nombre');
        return false;
      }
    
      return true;
    },
    
    
    // ----------------------------------------------------------------------
    
    // Ej: fn_sos().enviarofrecimientodeayuda();
    enviarofrecimientodeayuda: () => {
      // Envia los datos al servidor.
      fn_cargando().mostrar('Espera un momento ...');
      fn_sos().enviarofrecimiento((par_error, par_resultado) => {
        fn_sos().mostrarrespuesta();
        fn_cargando().ocultar();
        
        if (par_error) {
          let bvar_respuesta = document.getElementById('plantilla_confirmacion_error').innerHTML;
          document.getElementById('respuesta_texto').innerHTML = bvar_respuesta.replace(/_#error#_/gm, par_error);
        } else {
      
          objetohtml_estadonodisplay('datosiniciales_1');
          objetohtml_estadonodisplay('datosiniciales_2');
          objetohtml_estadodisplay('datosrecurrentes_1');
          objetohtml_estadodisplay('lista_boton');
      
          document.getElementById('categoria').value = '';
          document.getElementById('subcategoria').value ='';
          document.getElementById('descripcionayuda').value = '';
      
          let bvar_respuesta;
          if (valorentero(par_resultado) > 0) {
            bvar_respuesta = document.getElementById('plantilla_confirmacion_ok_si').innerHTML;
          } else {
            bvar_respuesta = document.getElementById('plantilla_confirmacion_ok_no').innerHTML;
          }
          document.getElementById('respuesta_texto').innerHTML = bvar_respuesta;
        }
      });
    },
    
    // Ej: fn_sos().enviarsolicituddeayuda();
    enviarsolicituddeayuda: () => {
      fn_cargando().mostrar('Espera un momento ...');
      fn_sos().enviarsolicitud((par_error, par_resultado) => {
        fn_sos().mostrarrespuesta();
        fn_cargando().ocultar();
        
        if (par_error) {
          let bvar_respuesta = document.getElementById('plantilla_confirmacion_error').innerHTML;
          document.getElementById('respuesta_texto').innerHTML = bvar_respuesta.replace(/_#error#_/gm, par_error);
        } else {
  
          objetohtml_estadonodisplay('datosiniciales_1');
          objetohtml_estadonodisplay('datosiniciales_2');
          objetohtml_estadodisplay('datosrecurrentes_1');
          objetohtml_estadodisplay('lista_boton');
  
          document.getElementById('categoria').value = '';
          document.getElementById('subcategoria').value ='';
          document.getElementById('descripcionayuda').value = '';
          
          let bvar_respuesta;
          if (valorentero(par_resultado) > 0) {
            bvar_respuesta = document.getElementById('plantilla_confirmacion_ok_si').innerHTML;
          } else {
            bvar_respuesta = document.getElementById('plantilla_confirmacion_ok_no').innerHTML;
          }
          document.getElementById('respuesta_texto').innerHTML = bvar_respuesta;
        }
        
      });
    },
    
    // Ej: fn_sos().yoayudo(callback);
    yoayudo: (par_callback) => {
      // Primero consulta datos del usuario para poder enviar el nombre.
      fn_redcs().usuarioconsultar((par_valor) => {
        if (!par_valor) {
          par_callback('Error al consultar el usuario.');
          return;
        }
        
        let bvar_arreglo = par_valor.split('_|_');
        // Hace post
        wspost_cb(
            {
              url: '/ws/app/solicitud',
              datos: 'config=' + conescape(JSON.stringify({
                comando: 'yoayudo',
                origen_id: document.getElementById('ofrecimiento_yoayudo').value,
                destino_id: document.getElementById('solicitud_yoayudo').value,
                nombreoferente: sinescape(bvar_arreglo[0])
              }))
            },
            (par_error, par_resultado) => {
              if (par_error) {
                par_callback(par_error);
              } else {
                par_callback(null, par_resultado);
              }
            });
      });
    },
    
    // Ej: fn_sos().cerrarcaso(callback);
    cerrarcaso: (par_callback) => {
      // Primero consulta datos del usuario para poder enviar el nombre.
      fn_redcs().usuarioconsultar((par_valor) => {
        if (!par_valor) {
          par_callback('Error al consultar el usuario.');
          return;
        }
        
        let bvar_arreglo = par_valor.split('_|_');
        // Hace post
        wspost_cb(
            {
              url: '/ws/app/solicitud',
              datos: 'config=' + conescape(JSON.stringify({
                comando: 'cerrarcaso',
                origen_id: document.getElementById('cerrar_solicitud').value,
                destino_id: document.getElementById('cerrar_ofrecimiento').value,
                completo: document.getElementById('completo').value,
                motivo: document.getElementById('motivo').value,
                aseguir: document.getElementById('aseguir').value,
                nombreoferente: sinescape(bvar_arreglo[0])
              }))
            },
            (par_error, par_resultado) => {
              if (par_error) {
                par_callback(par_error);
              } else {
                par_callback(null, par_resultado);
              }
            });
      });
    },
    
    // Ej: fn_sos().confirmarsolicitud(callback);
    confirmarsolicitud: (par_callback) => {
      // Primero consulta datos del usuario para poder enviar el nombre.
      fn_redcs().usuarioconsultar((par_valor) => {
        if (!par_valor) {
          par_callback('Error al consultar el usuario.');
          return;
        }
        
        let bvar_arreglo = par_valor.split('_|_');
        // Hace post
        wspost_cb(
            {
              url: '/ws/app/solicitud',
              datos: 'config=' + conescape(JSON.stringify({
                comando: 'confirmar',
                origen_id: document.getElementById('confirmarmeayudaron').value,
                satisfaccion: document.getElementById('satisfaccion').value,
                comentarioayudarecibida: document.getElementById('comentarioayudarecibida').value
              }))
            },
            (par_error, par_resultado) => {
              if (par_error) {
                par_callback(par_error);
              } else {
                par_callback(null, par_resultado);
              }
            });
      });
    },
    
    // Ej: fn_sos().borrarofrecimiento(callback);
    borrarofrecimiento: (par_callback) => {
      // Primero consulta datos del usuario para poder enviar el nombre.
      fn_redcs().usuarioconsultar((par_valor) => {
        if (!par_valor) {
          par_callback('Error al consultar el usuario.');
          return;
        }
        
        let bvar_arreglo = par_valor.split('_|_');
        // Hace post
        wspost_cb(
            {
              url: '/ws/app/ofrecimiento',
              datos: 'config=' + conescape(JSON.stringify({
                comando: 'borrar',
                origen_id: document.getElementById('borrar_ofrecimiento').value,
                motivodeborrar: document.getElementById('motivodeborrar').value
              }))
            },
            (par_error, par_resultado) => {
              if (par_error) {
                par_callback(par_error);
              } else {
                par_callback(null, par_resultado);
              }
            });
      });
    },
    
    // Ej: fn_sos().suspenderofrecimiento(callback);
    suspenderofrecimiento: (par_ofrecimiento_id, par_callback) => {
      // Primero consulta datos del usuario para poder enviar el nombre.
      fn_redcs().usuarioconsultar((par_valor) => {
        if (!par_valor) {
          par_callback('Error al consultar el usuario.');
          return;
        }
        
        let bvar_arreglo = par_valor.split('_|_');
        // Hace post
        wspost_cb(
            {
              url: '/ws/app/ofrecimiento',
              datos: 'config=' + conescape(JSON.stringify({
                comando: 'suspender',
                origen_id: par_ofrecimiento_id
              }))
            },
            (par_error, par_resultado) => {
              if (par_error) {
                par_callback(par_error);
              } else {
                par_callback(null, par_resultado);
              }
            });
      });
    },
    
    // Ej: fn_sos().agotarofrecimiento(callback);
    agotarofrecimiento: (par_ofrecimiento_id, par_callback) => {
      // Primero consulta datos del usuario para poder enviar el nombre.
      fn_redcs().usuarioconsultar((par_valor) => {
        if (!par_valor) {
          par_callback('Error al consultar el usuario.');
          return;
        }
        
        let bvar_arreglo = par_valor.split('_|_');
        // Hace post
        wspost_cb(
            {
              url: '/ws/app/ofrecimiento',
              datos: 'config=' + conescape(JSON.stringify({
                comando: 'agotar',
                origen_id: par_ofrecimiento_id
              }))
            },
            (par_error, par_resultado) => {
              if (par_error) {
                par_callback(par_error);
              } else {
                par_callback(null, par_resultado);
              }
            });
      });
    },
    
    // Ej: fn_sos().activarofrecimiento(callback);
    activarofrecimiento: (par_ofrecimiento_id, par_callback) => {
      // Primero consulta datos del usuario para poder enviar el nombre.
      fn_redcs().usuarioconsultar((par_valor) => {
        if (!par_valor) {
          par_callback('Error al consultar el usuario.');
          return;
        }
        
        let bvar_arreglo = par_valor.split('_|_');
        // Hace post
        wspost_cb(
            {
              url: '/ws/app/ofrecimiento',
              datos: 'config=' + conescape(JSON.stringify({
                comando: 'activar',
                origen_id: par_ofrecimiento_id
              }))
            },
            (par_error, par_resultado) => {
              if (par_error) {
                par_callback(par_error);
              } else {
                par_callback(null, par_resultado);
              }
            });
      });
    },
    
    // Ej: fn_sos().enviarsolicitud(callback);
    enviarsolicitud: (par_callback) => {
      // Valida primero los datos.
      if (!fn_sos().validarsolicituddeayuda()) {
        return;
      }
      
      let bvar_paquete = {
        comando: 'adicionar-ayuda',
        
        nombre: document.getElementById('nombre').value,
        documento: document.getElementById('documento').value,
        tipodocumento: document.getElementById('tipodocumento').value,
        correo: document.getElementById('correo').value,
        celular: document.getElementById('celular').value,
        ubicacionrural: document.getElementById('ubicacionrural').value,
        vereda: document.getElementById('vereda').value,
        direccion: document.getElementById('direccion').value,
        interior: document.getElementById('interior').value,
        ciudad: document.getElementById('ciudad').value,
        ubicacion: document.getElementById('ubicacion').value,
        telefono: document.getElementById('telefono').value,
        
        categoria: document.getElementById('categoria').value,
        subcategoria: document.getElementById('subcategoria').value,
        descripcionayuda: document.getElementById('descripcionayuda').value,
  
        aceptopublicarnombre: document.getElementById('aceptopublicarnombre').checked ? document.getElementById('aceptopublicarnombre').value : 'NO',
        aceptocontactocelular: document.getElementById('aceptocontactocelular').checked ? document.getElementById('aceptocontactocelular').value : 'NO',
        aceptocontactowhatsapp: document.getElementById('aceptocontactowhatsapp').checked ? document.getElementById('aceptocontactowhatsapp').value : 'NO',
        aceptocontactocorreo: document.getElementById('aceptocontactocorreo').checked ? document.getElementById('aceptocontactocorreo').value : 'NO',
        
        textodepolitica: document.getElementById('textodepolitica').innerHTML,
        politicaprivacidad: document.getElementById('politicaprivacidad').value
      };
      
      // Hace post
      wspost_cb(
          { url: '/ws/app/solicitud', datos: 'config=' + conescape(JSON.stringify(bvar_paquete)) },
          (par_error, par_resultado) => {
            if (par_error) {
              // alert('ERROR: ' + par_error);
              par_callback(par_error);
            } else {
              
              fn_redcs().variable('nombre').asignarvalor(bvar_paquete.nombre);
              // alert('OK: ' + par_resultado);
              par_callback(null, par_resultado);
            }
          });
    },
    
    // Ej: lvar_resultado = fn_sos().validarsolicituddeayuda();
    validarsolicituddeayuda: () => {
      if (!document.getElementById('nombre').value) {
        objetohtml_enfocar('nombre');
        alert('Debe ingresar un nombre');
        objetohtml_enfocar('nombre');
        return false;
      }
      
      if (!document.getElementById('categoria').value) {
        objetohtml_enfocar('categoria');
        alert('Debe seleccionar una categoría');
        objetohtml_enfocar('categoria');
        return false;
      }

      if (!document.getElementById('subcategoria').value && !document.getElementById('descripcionayuda').value) {
        objetohtml_enfocar('subcategoria');
        alert('Debe seleccionar un detalle de la ayuda o proporcionar una descripción breve.');
        objetohtml_enfocar('subcategoria');
        return false;
      }
      
      return true;
    },
    
    // Ej: fn_sos().enviarofrecimiento(callback);
    enviarofrecimiento: (par_callback) => {
      // Valida primero los datos.
      if (!fn_sos().validarofrecimiento()) {
        return;
      }
      
      let bvar_paquete = {
        comando: 'adicionar',
        
        nombre: document.getElementById('nombre').value,
        documento: document.getElementById('documento').value,
        tipodocumento: document.getElementById('tipodocumento').value,
        correo: document.getElementById('correo').value,
        celular: document.getElementById('celular').value,
        ubicacionrural: document.getElementById('ubicacionrural').value,
        vereda: document.getElementById('vereda').value,
        direccion: document.getElementById('direccion').value,
        interior: document.getElementById('interior').value,
        ciudad: document.getElementById('ciudad').value,
        ubicacion: document.getElementById('ubicacion').value,
        telefono: document.getElementById('telefono').value,
        
        categoria: document.getElementById('categoria').value,
        subcategoria: document.getElementById('subcategoria').value,
        descripcionayuda: document.getElementById('descripcionayuda').value,
  
        aceptopublicarnombre: document.getElementById('aceptopublicarnombre').checked ? document.getElementById('aceptopublicarnombre').value : 'NO',
        aceptocontactocelular: document.getElementById('aceptocontactocelular').checked ? document.getElementById('aceptocontactocelular').value : 'NO',
        aceptocontactowhatsapp: document.getElementById('aceptocontactowhatsapp').checked ? document.getElementById('aceptocontactowhatsapp').value : 'NO',
        aceptocontactocorreo: document.getElementById('aceptocontactocorreo').checked ? document.getElementById('aceptocontactocorreo').value : 'NO',
        
        textodepolitica: document.getElementById('textodepolitica').innerHTML,
        politicaprivacidad: document.getElementById('politicaprivacidad').value
      };
      
      // Hace post
      wspost_cb(
          { url: '/ws/app/ofrecimiento', datos: 'config=' + conescape(JSON.stringify(bvar_paquete)) },
          (par_error, par_resultado) => {
            if (par_error) {
              // alert('ERROR: ' + par_error);
              par_callback(par_error);
            } else {
              
              fn_redcs().variable('nombre').asignarvalor(bvar_paquete.nombre);
              // alert('OK: ' + par_resultado);
              par_callback(null, par_resultado);
            }
          });
    },
    
    // Ej: lvar_resultado = fn_sos().validarofrecimiento();
    validarofrecimiento: () => {
      if (!document.getElementById('nombre').value) {
        objetohtml_enfocar('nombre');
        alert('Debe ingresar un nombre');
        objetohtml_enfocar('nombre');
        return false;
      }
      
      if (!document.getElementById('categoria').value) {
        objetohtml_enfocar('categoria');
        alert('Debe seleccionar una categoría');
        objetohtml_enfocar('categoria');
        return false;
      }

      if (!document.getElementById('subcategoria').value && !document.getElementById('descripcionayuda').value) {
        objetohtml_enfocar('subcategoria');
        alert('Debe seleccionar un detalle de la ayuda o proporcionar una descripción breve.');
        objetohtml_enfocar('subcategoria');
        return false;
      }
      
      return true;
    }
    
  };
}
// ********************************************************************
// ********************************************************************


// ********************************************************************
// ********************************************************************
function fn_redcs() {
  return {
    // Ej.: fn_redcs().inicializar();
    inicializar: () => {
      fn_cargando().mostrar('Espera un momento ...');
      // ****************************************
      if (document.getElementById('encabezado_opcion_solicitudes')) {
        document.getElementById('encabezado_opcion_solicitudes').className =
            lsincat(document.getElementById('encabezado_opcion_solicitudes').className, 'active', ' ');
        document.getElementById('encabezado_opcion_ofrecimientos').className =
            lsincat(document.getElementById('encabezado_opcion_ofrecimientos').className, 'active', ' ');
        
        if ((window.location.href || '').includes('solicitudes.html')) {
          document.getElementById('encabezado_opcion_solicitudes').className =
              lconcat(document.getElementById('encabezado_opcion_solicitudes').className, 'active', ' ');
        }
        if ((window.location.href || '').includes('ofrecimientos.html')) {
          document.getElementById('encabezado_opcion_ofrecimientos').className =
              lconcat(document.getElementById('encabezado_opcion_ofrecimientos').className, 'active', ' ');
        }
      }
  
  
      // ****************************************
      fn_redcs.categoriasdefinidas = [];
      fn_redcs.estadosdefinidos = [];
      fn_redcs.categoriasxnombre = [];
  
  
      // ****************************************
      // ****************************************
      // Inicializa el campo de celular que es no modificable.
      fn_redcs().variable('celular').valor((par_error, par_valor) => {
        if (!par_error) {
          document.getElementById('celular').value = par_valor;
        }
    
        fn_redcs().usuarioconsultar((par_valor) => {
          if (par_valor) {
            let bvar_arreglo = par_valor.split('_|_');
            document.getElementById('nombre').value = sinescape(bvar_arreglo[0]);
            document.getElementById('nombrerecurrente').innerHTML = car(sinescape(bvar_arreglo[0]), ' ');
        
            objetohtml_estadodisplay('lista_boton');
          } else {
            objetohtml_estadodisplay('datosiniciales_1');
            objetohtml_estadodisplay('datosiniciales_2');
        
            objetohtml_estadonodisplay('datosrecurrentes_1');
          }
      
          fnlocal_categorias();
          fnlocal_politica();
  
          fn_cargando().ocultar();
        });
      });
    },
    
    
    // Ej.: fn_redcs().visitaropcion(opcion);
    visitaropcion: (par_opcion) => {
      if (par_opcion === '/redcs/') {
          window.location = par_opcion;
          return;
      }
      
      fn_redcs().usuarioautenticado((par_autenticado) => {
        if (par_autenticado) {
          // Si esta autenticado.
          window.location = par_opcion;
        
        } else {
          // NO esta autenticado.
          // TODO: Falta almacenar el valor de par_opcion en BD local para utilizarlo despues de autenticar
          window.location = '/redcs/autenticarusuario.html#destino=' + conescape(par_opcion);
        }
      });
    },
    
    
    variable: (par_nombre) => {
      return {
        // Ej: fn_redcs().variable(nombre).valor(fn callback(error, valor))
        valor: (par_callback) => {
          // Hace post
          wspost_cb(
              {
                url: '/ws/app/usuario',
                datos: 'config=' + conescape(JSON.stringify({
                  comando: 'variable-consultar',
                  nombre: par_nombre
                }))
              },
              (par_error, par_resultado) => {
                if (par_callback) {
                  if (par_error) {
                    par_callback(par_error);
                  } else {
                    par_callback(null, par_resultado);
                  }
                }
              });
        },
        // Ej: fn_redcs().variable(nombre).asignarvalor(valor [, fn callback(error)]);
        asignarvalor: (par_valor, par_callback) => {
          // Hace post
          wspost_cb(
              {
                url: '/ws/app/usuario',
                datos: 'config=' + conescape(JSON.stringify({
                  comando: 'variable-asignar',
                  nombre: par_nombre,
                  valor: par_valor
                }))
              },
              (par_error, par_resultado) => {
                if (par_callback) {
                  if (par_error) {
                    par_callback(false);
                  } else {
                    par_callback(true);
                  }
                }
              });
        }
      };
    },
    
    
    // Ej.: fn_redcs().usuariologout(callback);
    usuariologout: (par_callback) => {
      fn_cargando().mostrar('Espera un momento ...');
      // Hace post
      wspost_cb(
          {
            url: '/ws/app/usuario',
            datos: 'config=' + conescape(JSON.stringify({ comando: 'logout' }))
          },
          (par_error, par_resultado) => {
            fn_cargando().ocultar();
            if (par_error) {
              par_callback(false);
            } else {
              par_callback(true);
            }
          });
    },
  
    // Ej.: fn_redcs().usuarioautenticado(callback);
    usuarioautenticado: (par_callback) => {
      // Hace post
      wspost_cb(
          {
            url: '/ws/app/usuario',
            datos: 'config=' + conescape(JSON.stringify({ comando: 'usuarioautenticado' }))
          },
          (par_error, par_resultado) => {
            if (par_error) {
              par_callback(false);
            } else {
              par_callback(true);
            }
          });
    },
  
    
    // Ej.: fn_redcs().usuarioconsultar(callback);
    usuarioconsultar: (par_callback) => {
      // Hace post
      wspost_cb(
          {
            url: '/ws/app/usuario',
            datos: 'config=' + conescape(JSON.stringify({
              comando: 'usuario-consultar',
              listadecampos: '15202,15203,15204,15205,15206,15260,15246,15207,15258,15259,15208,15244,15266,15267,15268,15269,15270,15271'
            }))
          },
          (par_error, par_resultado) => {
            if (par_error) {
              par_callback('');
            } else {
              par_callback(par_resultado);
            }
          });
    },
    
    // Ej.: fn_redcs().usuariosolicitudes(callback);
    // Lista de columnas: objeto_id,objeto_estado_id,15212,15212.15202,15212.15205,15217,15218,15219,15221,15222
    usuariosolicitudes: (par_callback) => {
      // Hace post
      wspost_cb(
          {
            url: '/ws/app/usuario',
            datos: 'config=' + conescape(JSON.stringify({
              comando: 'solicitudes'
            }))
          },
          (par_error, par_resultado) => {
            if (par_error) {
              par_callback('');
            } else {
              par_callback(par_resultado);
            }
          });
    },
    
    // Ej.: fn_redcs().usuarioofrecimientos(callback);
    // Lista de columnas: objeto_id,objeto_estado_id,15226,15226.15202,15226.15205,15227,15228,15229
    usuarioofrecimientos: (par_callback) => {
      // Hace post
      wspost_cb(
          {
            url: '/ws/app/usuario',
            datos: 'config=' + conescape(JSON.stringify({
              comando: 'ofrecimientos'
            }))
          },
          (par_error, par_resultado) => {
            if (par_error) {
              par_callback('');
            } else {
              par_callback(par_resultado);
            }
          });
    },
    
    
    // ------------------------------------------
    
    
    // Ej.: fn_redcs().usuariopoliticas(callback);
    usuariopoliticas: (par_callback) => {
      // Hace post
      wspost_cb(
          {
            url: '/ws/app/usuario',
            datos: 'config=' + conescape(JSON.stringify({
              comando: 'politicas'
            }))
          },
          (par_error, par_resultado) => {
            if (par_error) {
              par_callback('');
            } else {
              par_callback(par_resultado);
            }
          });
    },
    // Ej.: fn_redcs().usuariocategorias(callback);
    usuariocategorias: (par_callback) => {
      // Hace post
      wspost_cb(
          {
            url: '/ws/app/usuario',
            datos: 'config=' + conescape(JSON.stringify({
              comando: 'categorias',
              listadecampos: '15211,15213,15215,15216'
            }))
          },
          (par_error, par_resultado) => {
            if (par_error) {
              par_callback('');
            } else {
              par_callback(par_resultado);
            }
          });
    },
    // Ej.: fn_redcs().usuarioestados(callback);
    // lista de columnas: estado_id,estado_clasificacion_id,estado_colordefondo,estado_colordefuente,estado_tituloparalistado
    usuarioestados: (par_callback) => {
      // Hace post
      wspost_cb(
          {
            url: '/ws/app/usuario',
            datos: 'config=' + conescape(JSON.stringify({
              comando: 'estados',
              listadecampos: '15211,15213,15215,15216'
            }))
          },
          (par_error, par_resultado) => {
            if (par_error) {
              par_callback('');
            } else {
              par_callback(par_resultado);
            }
          });
    },
    // Ej.: fn_redcs().usuarioveredas(callback);
    usuarioveredas: (par_callback) => {
      // Hace post
      wspost_cb(
          {
            url: '/ws/app/usuario',
            datos: 'config=' + conescape(JSON.stringify({
              comando: 'veredas',
              listadecampos: '15245'
            }))
          },
          (par_error, par_resultado) => {
            if (par_error) {
              par_callback('');
            } else {
              par_callback(par_resultado);
            }
          });
    },
  
    
    
    // Ej.: fn_redcs().autenticarusuario_paso1(celular, callback);
    autenticarusuario_paso1: (par_celular, par_callback) => {
      // Hace post
      wspost_cb(
          {
            url: '/ws/app/usuario',
            datos: 'config=' + conescape(JSON.stringify({
              comando: 'autenticarusuario_paso1',
              celular: par_celular // xxx
            }))
          },
          (par_error, par_resultado) => {
            if (par_error) {
              par_callback(false);
            } else {
              par_callback(true);
            }
          });
    },
  
    // Ej.: fn_redcs().autenticarusuario_paso2(celular, codigo, callback);
    autenticarusuario_paso2: (par_celular, par_codigo, par_callback) => {
      // Hace post
      wspost_cb(
          {
            url: '/ws/app/usuario',
            datos: 'config=' + conescape(JSON.stringify({
              comando: 'autenticarusuario_paso2',
              celular: par_celular,
              codigo: par_codigo
            }))
          },
          (par_error, par_resultado) => {
            if (par_error) {
              par_callback(false);
            } else {
              fn_redcs().variable('celular').asignarvalor(par_celular, () => { });
              par_callback(true);
            }
          });
    }
  };
}
// ********************************************************************
// ********************************************************************

// ********************************************************************
// ********************************************************************
function redcs_init(par_callback) {
  // Oculta (eventualmente) el boton de usuario.
  fn_redcs().usuarioautenticado((par_ok) => {
    if (!par_ok) {
      // No se ha identificado con celular.
      objetohtml_estadonodisplay('botondeusuario');
      par_callback();
      return;
    }
    
    // Ya se identifico con celular.
    fn_redcs().usuarioconsultar((par_valor) => {
      if (par_valor) {
        let bvar_arreglo = par_valor.split('_|_');
        
        if (getComputedStyle(document.getElementById('testigo_responsive')).display === 'none') {
          // Responsive
          // El primer nombre completo en el boton.
          // alert(sinescape(bvar_arreglo[0]));
          document.getElementById('sigladeusuario').innerHTML = car(sinescape(bvar_arreglo[0]), ' ');
        } else {
          // Primera letra del nombre en mayuscula en el boton.
          document.getElementById('sigladeusuario').innerHTML = left(sinescape(bvar_arreglo[0]), 1).toUpperCase();
        }
        
        
        document.getElementById('sigladeusuario').title = car(sinescape(bvar_arreglo[0]), ' ');
        
      } else {
        // Todavia no ha hecho el primer POST y entonces todavia no tiene nombre.
        objetohtml_estadonodisplay('botondeusuario');
      }
  
      par_callback();
    });
  });
}

// ********************************************************************
window.setTimeout(() => {
  fn_cargando().mostrar('Espera un momento ...');
  redcs_init(() => {
    fn_cargando().ocultar();
  });
}, 300);
// ********************************************************************
// ********************************************************************
